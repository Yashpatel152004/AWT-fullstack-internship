 <script type="text/javascript" language="javascript">
                //JQuery makes a use of anonymous functions
                $(document).ready(function() {
                        //Set text using class name
                        $(".lbMessage").text("Welcome to JavaScript ");
                        //Apply css to all H1 tage
                        $("h1").css("background-color", "Lightblue");
                        $("#btnGetLenght").click(function() {
                                stringLength(); //Call external file function
                        });
                });
        </script>