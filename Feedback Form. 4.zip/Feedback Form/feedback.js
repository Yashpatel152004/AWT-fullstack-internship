
function myFunction() {
  alert("your feedback sent successfully");
}